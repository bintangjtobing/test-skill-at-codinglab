<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\kelas;
use App\guru;
use App\siswa;
use Illuminate\Support\Facades\DB;

class homeController extends Controller
{
    public function index()
    {
        $join = DB::table('guru')
            ->join('siswa', 'siswa.nim', '=', 'guru.nim')
            ->join('kelas', 'kelas.kode_kelas', '=', 'guru.kode_kelas')
            ->select('siswa.nim', 'siswa.nama_siswa', 'guru.nama_pengajar', 'kelas.nama_kelas')
            ->orderBy('siswa.created_at', 'DESC')
            ->get();
        $guru = guru::all();
        $kelas = kelas::all();
        // dd($join);
        return view('welcome', ['join' => $join, 'guru' => $guru, 'kelas' => $kelas]);
    }
    public function tambahSiswa(Request $request)
    {
        $getDataGuru = guru::where('nip', '=', $request->nip)->first();
        $post = new siswa();
        $post->nim = $request->nim;
        $post->nama_siswa = $request->nama_siswa;
        $post->save();

        $postG = new guru();
        $postG->nip = $request->nip;
        $postG->nim = $request->nim;
        $postG->kode_kelas = $request->kode_kelas;
        $postG->nama_pengajar = $getDataGuru->nama_pengajar;
        $postG->save();
        return back()->with('success', 'Berhasil menambahkan siswa nya!');
    }
    public function hapusSiswa($nim)
    {
        $getSiswa = siswa::where('nim', $nim)->delete();
        $deleteGuru = guru::where('nim', $nim)->delete();
        return back()->with('successDelete', 'Berhasil menghapus siswa nya!');
    }
    public function getSiswa($nim)
    {
        $getSiswa = siswa::where('nim', $nim)->first();
        $guru = guru::all();
        $kelas = kelas::all();
        return view('ubahSiswa', ['getSiswa' => $getSiswa, 'guru' => $guru, 'kelas' => $kelas]);
    }
    public function postSiswa(Request $request, $nim)
    {
        $getDataGuru = guru::where('nip', '=', $request->nip)->first();
        $post =
            siswa::where('nim', $nim)->first();
        $post->nim = $request->nim;
        $post->nama_siswa = $request->nama_siswa;
        $post->save();

        $postG = guru::where('nip', '=', $request->nip)->first();
        $postG->nip = $request->nip;
        $postG->nim = $request->nim;
        $postG->kode_kelas = $request->kode_kelas;
        $postG->nama_pengajar = $getDataGuru->nama_pengajar;
        $postG->save();
        return redirect()->route('index');
    }
}
