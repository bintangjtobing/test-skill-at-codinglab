## About This Test

Please install with :
- Copy .env.example and
- Paste with .env
- Please set the database name, also with username and password (codinglab_testing, root, password)
